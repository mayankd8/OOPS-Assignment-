package JavaAssignment2;
import java.util.Scanner;
class Que5
{
    public static void main (String args[])
    {
        int i,j,a,b,flag;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the starting no");
        a=sc.nextInt();
        System.out.println("Enter the last no");
        b=sc.nextInt();
        sc.close();
    
        for(i=a;i<=b;i++)
        {
            flag=1;
            for(j=2;j<=i/2;j++)
            {
                if(i%j==0){
                    flag=0;
                    break;
                }
            }
            if(flag == 1)
                System.out.println(i);
        }
                
    }
}