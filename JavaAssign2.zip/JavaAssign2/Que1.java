package JavaAssignment2;
import java.util.Scanner;
class Que1
{
    public static void main (String args[])
    {
        Scanner sc=new  Scanner(System.in);
                int a=sc.nextInt();
                for(int i=1;i<=10;i++)
                {
                    System.out.println(a+"x"+i+"="+(a*i));
                }
    }
}