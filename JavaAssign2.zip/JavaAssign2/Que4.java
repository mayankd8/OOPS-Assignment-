package JavaAssignment2;

class Que4
{
    public static void main(String args[])
    {
       int i,sum=0;
       for (i=12;i<=102;i=i+10)
       {
           System.out.print(" "+i);
           sum=sum+i;
       }
        System.out.println(" "+sum);
    }
}